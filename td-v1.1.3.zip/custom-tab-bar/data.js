export default [
  {
    icon: 'home',
    text: '首页',
    url: 'pages/home/home',
  },
  {
    icon: 'sort',
    text: '分类',
    url: 'pages/goods/category/index',
  },
  {
    icon: 'cart',
    text: '购物车',
    url: 'pages/cart/index',
  },
  {
    icon: 'person',
    text: '个人中心',
    url: 'pages/usercenter/index',
  },
];
