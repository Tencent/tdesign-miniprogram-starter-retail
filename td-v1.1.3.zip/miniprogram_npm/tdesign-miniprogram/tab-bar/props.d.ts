import { TdTabBarProps } from './type';
declare const props: TdTabBarProps;
export default props;
