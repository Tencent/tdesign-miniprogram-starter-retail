import { TdInputProps } from './type';
declare const props: TdInputProps;
export default props;
