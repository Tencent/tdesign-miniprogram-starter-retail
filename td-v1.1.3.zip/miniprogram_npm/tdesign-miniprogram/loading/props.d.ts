import { TdLoadingProps } from './type';
declare const props: TdLoadingProps;
export default props;
