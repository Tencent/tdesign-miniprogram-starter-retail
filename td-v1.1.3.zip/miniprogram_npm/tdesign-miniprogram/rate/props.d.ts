import { TdRateProps } from './type';
declare const props: TdRateProps;
export default props;
