:: BASE_DOC ::

## API
### CellGroup Props

name | type | default | description | required
-- | -- | -- | -- | --
bordered | Boolean | - | \- | N
custom-style `v0.25.0` | String | - | \- | N
external-classes | Array | - | `['t-class']` | N
theme | String | default | options：default/card | N
title | String | - | \- | N
