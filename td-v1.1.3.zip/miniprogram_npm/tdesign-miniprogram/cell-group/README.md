:: BASE_DOC ::

## API
### CellGroup Props

名称 | 类型 | 默认值 | 说明 | 必传
-- | -- | -- | -- | --
bordered | Boolean | - | 是否显示组边框 | N
custom-style `v0.25.0` | String | - | 自定义组件样式 | N
external-classes | Array | - | 组件类名。`['t-class']` | N
theme | String | default | 单元格风格。可选项：default/card | N
title | String | - | 单元格组标题 | N
