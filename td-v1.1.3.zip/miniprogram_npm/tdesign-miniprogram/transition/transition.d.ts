import { SuperComponent } from '../common/src/index';
export default class Transition extends SuperComponent {
    behaviors: string[];
}
