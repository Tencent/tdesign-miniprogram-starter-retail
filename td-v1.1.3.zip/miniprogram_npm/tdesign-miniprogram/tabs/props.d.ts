import { TdTabsProps } from './type';
declare const props: TdTabsProps;
export default props;
