:: BASE_DOC ::

## API
### Fab Props

name | type | default | description | required
-- | -- | -- | -- | --
button-props | Object | - | \- | N
custom-style `v0.25.0` | String | right: 16px; bottom: 32px; | \- | N
icon | String | - | \- | N
style | String | right: 16px; bottom: 32px; | \- | N
text | String | - | \- | N

### Fab Events

name | params | description
-- | -- | --
click | `(detail: {e: MouseEvent})` | \-
