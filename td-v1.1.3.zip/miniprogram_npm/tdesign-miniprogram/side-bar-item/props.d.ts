import { TdSideBarItemProps } from './type';
declare const props: TdSideBarItemProps;
export default props;
