import { TdToastProps } from './type';
declare const props: TdToastProps;
export default props;
