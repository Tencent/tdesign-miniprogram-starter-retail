const props = {
    badgeProps: {
        type: Object,
    },
    style: {
        type: String,
        value: '',
    },
    icon: {
        type: String,
    },
    subTabBar: {
        type: Array,
    },
    value: {
        type: null,
    },
};
export default props;
