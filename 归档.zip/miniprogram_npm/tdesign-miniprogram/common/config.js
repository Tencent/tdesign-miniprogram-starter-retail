export default {
    prefix: "t",
};

//# sourceMappingURL=config.js.map
