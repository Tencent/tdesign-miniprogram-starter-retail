declare const DIRECTION: {
    HOR: string;
    VER: string;
};
declare const enum NavTypes {
    none = "",
    dots = "dots",
    dotsBar = "dots-bar",
    fraction = "fraction"
}
export { DIRECTION, NavTypes };
