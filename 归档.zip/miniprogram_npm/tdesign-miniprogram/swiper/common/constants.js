const DIRECTION = {
    // 水平
    HOR: 'horizontal',
    // 垂直
    VER: 'vertical',
};
export { DIRECTION };

//# sourceMappingURL=constants.js.map
