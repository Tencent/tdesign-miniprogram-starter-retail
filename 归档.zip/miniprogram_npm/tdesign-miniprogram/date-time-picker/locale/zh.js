export default {
    year: '年',
    month: '月',
    day: '日',
    hour: '时',
    minute: '分',
    am: '上午',
    pm: '下午',
    confirm: '确定',
    cancel: '取消',
};

//# sourceMappingURL=zh.js.map
