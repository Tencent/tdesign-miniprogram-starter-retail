/**
 * 该文件为脚本自动生成文件，请勿随意修改。如需修改请联系 PMC
 * updated at 2022-01-11 17:36:12
 * */
import { TdCellProps } from './type';
declare const props: TdCellProps;
export default props;
