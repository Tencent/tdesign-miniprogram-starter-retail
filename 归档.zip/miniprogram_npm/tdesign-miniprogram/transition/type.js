/**
 * 该文件为脚本自动生成文件，请勿随意修改。如需修改请联系 PMC
 * updated at 2021-08-03 16:17:22
 * */
;
export {};

//# sourceMappingURL=type.js.map
